-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: bigdata
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `top10romantic`
--

DROP TABLE IF EXISTS `top10romantic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `top10romantic` (
  `imdbID` text,
  `Director` text,
  `Title` text,
  `Actirs` text,
  `imdbRating` double DEFAULT NULL,
  `imdbVote` int(11) DEFAULT NULL,
  `runtime` int(11) DEFAULT NULL,
  `Awards` text,
  `Year` int(11) DEFAULT NULL,
  `Language` text,
  `Country` text,
  `Writer` text,
  `Poster` text,
  `OscarWinner` int(11) DEFAULT NULL,
  `OscarNominated` int(11) DEFAULT NULL,
  `otherAwards` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top10romantic`
--

LOCK TABLES `top10romantic` WRITE;
/*!40000 ALTER TABLE `top10romantic` DISABLE KEYS */;
INSERT INTO `top10romantic` VALUES ('tt0034583','Michael Curtiz','Casablanca','Humphrey Bogart	 Ingrid Bergman	 Paul Henreid	 Claude Rains',8.6,395848,102,'Won 3 Oscars. Another 4 wins & 8 nominations.',1942,'English	 French	 German	 Italian','Drama	 Romance	 War','Julius J. Epstein (screenplay)	 Philip G. Epstein (screenplay)	 Howard Koch (screenplay)	 Murray Burnett (play)	 Joan Alison (play)','https://images-na.ssl-images-amazon.com/images/M/MV5BMjQwNDYyNTk2N15BMl5BanBnXkFtZTgwMjQ0OTMyMjE@._V1_SX300.jpg',3,0,12),('tt0169547','Sam Mendes','American Beauty','Kevin Spacey	 Annette Bening	 Thora Birch	 Wes Bentley',8.4,840591,122,'Won 5 Oscars. Another 103 wins & 96 nominations.',1999,'English','Drama	 Romance','Alan Ball','https://images-na.ssl-images-amazon.com/images/M/MV5BMjM4NTI5NzYyNV5BMl5BanBnXkFtZTgwNTkxNTYxMTE@._V1_SX300.jpg',5,0,199),('tt0053291','Billy Wilder','Some Like It Hot','Marilyn Monroe	 Tony Curtis	 Jack Lemmon	 George Raft',8.3,179338,120,'Won 1 Oscar. Another 9 wins & 13 nominations.',1959,'English','Comedy	 Romance','Billy Wilder (screenplay)	 I.A.L. Diamond (screenplay)	 Robert Thoeren (suggested by a story by)	 Michael Logan (suggested by a story by)','https://images-na.ssl-images-amazon.com/images/M/MV5BNzYzMDkzNDQ0N15BMl5BanBnXkFtZTcwNzQ0NDQyNA@@._V1_SX300.jpg',1,0,22),('tt0053604','Billy Wilder','The Apartment','Jack Lemmon	 Shirley MacLaine	 Fred MacMurray	 Ray Walston',8.3,112609,125,'Won 5 Oscars. Another 19 wins & 8 nominations.',1960,'English','Comedy	 Drama	 Romance','Billy Wilder	 I.A.L. Diamond','https://images-na.ssl-images-amazon.com/images/M/MV5BMTM1OTc4MzgzNl5BMl5BanBnXkFtZTcwNTE2NjgyMw@@._V1_SX300.jpg',5,0,27),('tt0031381','Victor Fleming	 George Cukor	 Sam Wood','Gone with the Wind','Thomas Mitchell	 Barbara O\'Neil	 Vivien Leigh	 Evelyn Keyes',8.2,220463,238,'Won 8 Oscars. Another 9 wins & 8 nominations.',1939,'English','Drama	 History	 Romance','Margaret Mitchell (story of the old south Gone with the Wind)	 Sidney Howard (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BYWQwOWVkMGItMDU2Yy00YjIzLWJkMjEtNmVkZjE3MjMwYzEzXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_SX300.jpg',8,0,17),('tt0025316','Frank Capra','It Happened One Night','Clark Gable	 Claudette Colbert	 Walter Connolly	 Roscoe Karns',8.2,66525,105,'Won 5 Oscars. Another 5 wins & 1 nomination.',1934,'English','Comedy	 Romance','Robert Riskin (screen play)	 Samuel Hopkins Adams (based on the short story by)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTczOTQ1MTQ4MF5BMl5BanBnXkFtZTcwODI2MDk4OQ@@._V1_SX300.jpg',5,0,6),('tt0079579','Vladimir Menshov','Moscow Does Not Believe in Tears','Vera Alentova	 Aleksey Batalov	 Irina Muravyova	 Raisa Ryazanova',8.2,8026,150,'Won 1 Oscar. Another 2 wins & 1 nomination.',1980,'Russian','Comedy	 Drama	 Romance','Valentin Chernykh	 Vladimir Menshov','https://images-na.ssl-images-amazon.com/images/M/MV5BMTIyMDcxMjQzMV5BMl5BanBnXkFtZTcwMDEyMDUyMQ@@._V1_SX300.jpg',1,0,3),('tt0075686','Woody Allen','Annie Hall','Woody Allen	 Diane Keaton	 Tony Roberts	 Carol Kane',8.1,197421,93,'Won 4 Oscars. Another 26 wins & 8 nominations.',1977,'English	 German','Comedy	 Romance','Woody Allen	 Marshall Brickman','https://images-na.ssl-images-amazon.com/images/M/MV5BMTU1NDM2MjkwM15BMl5BanBnXkFtZTcwODU3OTYwNA@@._V1_SX300.jpg',4,0,34);
/*!40000 ALTER TABLE `top10romantic` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-12 11:55:25
