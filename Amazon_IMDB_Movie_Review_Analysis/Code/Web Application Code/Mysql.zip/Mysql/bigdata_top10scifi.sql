-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: bigdata
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `top10scifi`
--

DROP TABLE IF EXISTS `top10scifi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `top10scifi` (
  `imdbID` text,
  `Director` text,
  `Title` text,
  `Actirs` text,
  `imdbRating` double DEFAULT NULL,
  `imdbVote` int(11) DEFAULT NULL,
  `runtime` int(11) DEFAULT NULL,
  `Awards` text,
  `Year` int(11) DEFAULT NULL,
  `Language` text,
  `Country` text,
  `Writer` text,
  `Poster` text,
  `OscarWinner` int(11) DEFAULT NULL,
  `OscarNominated` int(11) DEFAULT NULL,
  `otherAwards` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top10scifi`
--

LOCK TABLES `top10scifi` WRITE;
/*!40000 ALTER TABLE `top10scifi` DISABLE KEYS */;
INSERT INTO `top10scifi` VALUES ('tt1375666','Christopher Nolan','Inception','Leonardo DiCaprio	 Joseph Gordon-Levitt	 Ellen Page	 Tom Hardy',8.8,1501172,148,'Won 4 Oscars. Another 144 wins & 198 nominations.',2010,'English	 Japanese	 French','Action	 Adventure	 Sci-Fi','Christopher Nolan','https://images-na.ssl-images-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_SX300.jpg',4,0,342),('tt0133093','Lana Wachowski	 Lilly Wachowski','The Matrix','Keanu Reeves	 Laurence Fishburne	 Carrie-Anne Moss	 Hugo Weaving',8.7,1244275,136,'Won 4 Oscars. Another 33 wins & 43 nominations.',1999,'English','Action	 Sci-Fi','Lilly Wachowski	 Lana Wachowski','https://images-na.ssl-images-amazon.com/images/M/MV5BMDMyMmQ5YzgtYWMxOC00OTU0LWIwZjEtZWUwYTY5MjVkZjhhXkEyXkFqcGdeQXVyNDYyMDk5MTU@._V1_SX300.jpg',4,0,76),('tt0103064','James Cameron','Terminator 2: Judgment Day','Arnold Schwarzenegger	 Linda Hamilton	 Edward Furlong	 Robert Patrick',8.5,759731,137,'Won 4 Oscars. Another 21 wins & 22 nominations.',1991,'English	 Spanish','Action	 Sci-Fi	 Thriller','James Cameron	 William Wisher Jr.','https://images-na.ssl-images-amazon.com/images/M/MV5BZDM2YjYwYWMtMWZlNi00ZDQxLWExMDctMDAzNzQ0OTkzZjljXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',4,0,43),('tt0078748','Ridley Scott','Alien','Tom Skerritt	 Sigourney Weaver	 Veronica Cartwright	 Harry Dean Stanton',8.5,580179,117,'Won 1 Oscar. Another 16 wins & 19 nominations.',1979,'English	 Spanish','Horror	 Sci-Fi','Dan O\'Bannon (story)	 Ronald Shusett (story)	 Dan O\'Bannon (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BNDNhN2IxZWItNGEwYS00ZDNhLThiM2UtODU3NWJlZjBkYjQxXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',1,0,35),('tt0088763','Robert Zemeckis','Back to the Future','Michael J. Fox	 Christopher Lloyd	 Lea Thompson	 Crispin Glover',8.5,749874,116,'Won 1 Oscar. Another 18 wins & 26 nominations.',1985,'English','Adventure	 Comedy	 Sci-Fi','Robert Zemeckis	 Bob Gale','https://images-na.ssl-images-amazon.com/images/M/MV5BZmU0M2Y1OGUtZjIxNi00ZjBkLTg1MjgtOWIyNThiZWIwYjRiXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',1,0,44),('tt0090605','James Cameron','Aliens','Sigourney Weaver	 Carrie Henn	 Michael Biehn	 Paul Reiser',8.4,500006,137,'Won 2 Oscars. Another 17 wins & 22 nominations.',1986,'English','Action	 Adventure	 Sci-Fi','James Cameron (story)	 David Giler (story)	 Walter Hill (story)	 Dan O\'Bannon (characters)	 Ronald Shusett (characters)	 James Cameron (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BOTYxZGJkNDUtOWRmMy00M2JjLWJiNjAtNTE0OWU0ODU1MDdiXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',2,0,39),('tt0062622','Stanley Kubrick','2001: A Space Odyssey','Keir Dullea	 Gary Lockwood	 William Sylvester	 Daniel Richter',8.3,437932,149,'Won 1 Oscar. Another 13 wins & 7 nominations.',1968,'English	 Russian','Adventure	 Mystery	 Sci-Fi','Stanley Kubrick (screenplay)	 Arthur C. Clarke (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTZkZTBhYmUtMTIzNy00YTViLTg1OWItNGUwMmVlN2FjZTVkXkEyXkFqcGdeQXVyNDYyMDk5MTU@._V1_SX300.jpg',1,0,20),('tt0107290','Steven Spielberg','Jurassic Park','Sam Neill	 Laura Dern	 Jeff Goldblum	 Richard Attenborough',8.1,632890,127,'Won 3 Oscars. Another 28 wins & 17 nominations.',1993,'English	 Spanish','Adventure	 Sci-Fi	 Thriller','Michael Crichton (novel)	 Michael Crichton (screenplay)	 David Koepp (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BMjM2MDgxMDg0Nl5BMl5BanBnXkFtZTgwNTM2OTM5NDE@._V1_SX300.jpg',3,0,45),('tt0083866','Steven Spielberg','E.T. the Extra-Terrestrial','Dee Wallace	 Henry Thomas	 Peter Coyote	 Robert MacNaughton',7.9,288874,115,'Won 4 Oscars. Another 47 wins & 32 nominations.',1982,'English','Family	 Sci-Fi','Melissa Mathison','https://images-na.ssl-images-amazon.com/images/M/MV5BMTQ2ODFlMDAtNzdhOC00ZDYzLWE3YTMtNDU4ZGFmZmJmYTczXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',4,0,79),('tt0022835','Rouben Mamoulian','Dr. Jekyll and Mr. Hyde','Fredric March	 Miriam Hopkins	 Rose Hobart	 Holmes Herbert',7.7,9513,98,'Won 1 Oscar. Another 2 wins & 2 nominations.',1931,'English','Horror	 Sci-Fi','Samuel Hoffenstein (screen play)	 Percy Heath (screen play)	 Robert Louis Stevenson (based on the novel by)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTc1MjE3NTMxNV5BMl5BanBnXkFtZTgwMTQ0NzkxMjE@._V1_SX300.jpg',1,0,4);
/*!40000 ALTER TABLE `top10scifi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-12 11:55:25
