-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: bigdata
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `top10comedies`
--

DROP TABLE IF EXISTS `top10comedies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `top10comedies` (
  `imdbID` text,
  `Director` text,
  `Title` text,
  `Actirs` text,
  `imdbRating` double DEFAULT NULL,
  `imdbVote` int(11) DEFAULT NULL,
  `runtime` int(11) DEFAULT NULL,
  `Awards` text,
  `Year` int(11) DEFAULT NULL,
  `Language` text,
  `Country` text,
  `Writer` text,
  `Poster` text,
  `OscarWinner` int(11) DEFAULT NULL,
  `OscarNominated` int(11) DEFAULT NULL,
  `otherAwards` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top10comedies`
--

LOCK TABLES `top10comedies` WRITE;
/*!40000 ALTER TABLE `top10comedies` DISABLE KEYS */;
INSERT INTO `top10comedies` VALUES ('tt0109830','Robert Zemeckis','Forrest Gump','Tom Hanks	 Rebecca Williams	 Sally Field	 Michael Conner Humphreys',8.8,1291467,142,'Won 6 Oscars. Another 39 wins & 65 nominations.',1994,'English','Comedy	 Drama','Winston Groom (novel)	 Eric Roth (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BYThjM2MwZGMtMzg3Ny00NGRkLWE4M2EtYTBiNWMzOTY0YTI4XkEyXkFqcGdeQXVyNDYyMDk5MTU@._V1_SX300.jpg',6,0,104),('tt0118799','Roberto Benigni','Life Is Beautiful','Roberto Benigni	 Nicoletta Braschi	 Giorgio Cantarini	 Giustino Durano',8.6,433531,116,'Won 3 Oscars. Another 66 wins & 46 nominations.',1997,'Italian	 German	 English','Comedy	 Drama	 War','Vincenzo Cerami (story and screenplay by)	 Roberto Benigni (story and screenplay by)','https://images-na.ssl-images-amazon.com/images/M/MV5BYmJmM2Q4NmMtYThmNC00ZjRlLWEyZmItZTIwOTBlZDQ3NTQ1XkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',3,0,112),('tt0088763','Robert Zemeckis','Back to the Future','Michael J. Fox	 Christopher Lloyd	 Lea Thompson	 Crispin Glover',8.5,749874,116,'Won 1 Oscar. Another 18 wins & 26 nominations.',1985,'English','Adventure	 Comedy	 Sci-Fi','Robert Zemeckis	 Bob Gale','https://images-na.ssl-images-amazon.com/images/M/MV5BZmU0M2Y1OGUtZjIxNi00ZjBkLTg1MjgtOWIyNThiZWIwYjRiXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',1,0,44),('tt0053291','Billy Wilder','Some Like It Hot','Marilyn Monroe	 Tony Curtis	 Jack Lemmon	 George Raft',8.3,179338,120,'Won 1 Oscar. Another 9 wins & 13 nominations.',1959,'English','Comedy	 Romance','Billy Wilder (screenplay)	 I.A.L. Diamond (screenplay)	 Robert Thoeren (suggested by a story by)	 Michael Logan (suggested by a story by)','https://images-na.ssl-images-amazon.com/images/M/MV5BNzYzMDkzNDQ0N15BMl5BanBnXkFtZTcwNzQ0NDQyNA@@._V1_SX300.jpg',1,0,22),('tt0053604','Billy Wilder','The Apartment','Jack Lemmon	 Shirley MacLaine	 Fred MacMurray	 Ray Walston',8.3,112609,125,'Won 5 Oscars. Another 19 wins & 8 nominations.',1960,'English','Comedy	 Drama	 Romance','Billy Wilder	 I.A.L. Diamond','https://images-na.ssl-images-amazon.com/images/M/MV5BMTM1OTc4MzgzNl5BMl5BanBnXkFtZTcwNTE2NjgyMw@@._V1_SX300.jpg',5,0,27),('tt0266543','Andrew Stanton	 Lee Unkrich','Finding Nemo','Albert Brooks	 Ellen DeGeneres	 Alexander Gould	 Willem Dafoe',8.2,712073,100,'Won 1 Oscar. Another 46 wins & 58 nominations.',2003,'English','Animation	 Adventure	 Comedy','Andrew Stanton (original story by)	 Andrew Stanton (screenplay)	 Bob Peterson (screenplay)	 David Reynolds (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BZTAzNWZlNmUtZDEzYi00ZjA5LWIwYjEtZGM1NWE1MjE4YWRhXkEyXkFqcGdeQXVyNjU0OTQ0OTY@._V1_SX300.jpg',1,0,104),('tt0079579','Vladimir Menshov','Moscow Does Not Believe in Tears','Vera Alentova	 Aleksey Batalov	 Irina Muravyova	 Raisa Ryazanova',8.2,8026,150,'Won 1 Oscar. Another 2 wins & 1 nomination.',1980,'Russian','Comedy	 Drama	 Romance','Valentin Chernykh	 Vladimir Menshov','https://images-na.ssl-images-amazon.com/images/M/MV5BMTIyMDcxMjQzMV5BMl5BanBnXkFtZTcwMDEyMDUyMQ@@._V1_SX300.jpg',1,0,3),('tt0031679','Frank Capra','Mr. Smith Goes to Washington','Jean Arthur	 James Stewart	 Claude Rains	 Edward Arnold',8.2,78918,129,'Won 1 Oscar. Another 4 wins & 11 nominations.',1939,'English','Comedy	 Drama','Sidney Buchman (screen play)	 Lewis R. Foster (story)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTAxMjRiMGUtN2Q1Zi00ODg5LThhMTItMTJmNTRmYWFhNGRjXkEyXkFqcGdeQXVyNTA4NzY1MzY@._V1_SX300.jpg',1,0,15),('tt2096673','Pete Docter	 Ronnie Del Carmen','Inside Out','Amy Poehler	 Phyllis Smith	 Richard Kind	 Bill Hader',8.2,375070,95,'Won 1 Oscar. Another 92 wins & 95 nominations.',2015,'English','Animation	 Adventure	 Comedy','Pete Docter (original story by)	 Ronnie Del Carmen (original story by)	 Pete Docter (screenplay)	 Meg LeFauve (screenplay)	 Josh Cooley (screenplay)	 Michael Arndt (additional story material by)	 Bill Hader (additional dialogue by)	 Amy Poehler (additional dialogue by)	 Simon Rich (additional story material by)','https://images-na.ssl-images-amazon.com/images/M/MV5BOTgxMDQwMDk0OF5BMl5BanBnXkFtZTgwNjU5OTg2NDE@._V1_SX300.jpg',1,0,187),('tt0070510','Peter Bogdanovich','Paper Moon','Ryan O\'Neal	 Tatum O\'Neal	 Madeline Kahn	 John Hillerman',8.2,23587,102,'Won 1 Oscar. Another 7 wins & 10 nominations.',1973,'English','Comedy	 Crime	 Drama','Joe David Brown (novel)	 Alvin Sargent (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BOWVmYzQwY2MtOTBjNi00MDNhLWI5OGMtN2RiMDYxODI3MjU5XkEyXkFqcGdeQXVyMjUzOTY1NTc@._V1_SX300.jpg',1,0,17);
/*!40000 ALTER TABLE `top10comedies` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-12 11:55:24
