-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: bigdata
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `top10mysthrill`
--

DROP TABLE IF EXISTS `top10mysthrill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `top10mysthrill` (
  `imdbID` text,
  `Director` text,
  `Title` text,
  `Actirs` text,
  `imdbRating` double DEFAULT NULL,
  `imdbVote` int(11) DEFAULT NULL,
  `runtime` int(11) DEFAULT NULL,
  `Awards` text,
  `Year` int(11) DEFAULT NULL,
  `Language` text,
  `Country` text,
  `Writer` text,
  `Poster` text,
  `OscarWinner` int(11) DEFAULT NULL,
  `OscarNominated` int(11) DEFAULT NULL,
  `otherAwards` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top10mysthrill`
--

LOCK TABLES `top10mysthrill` WRITE;
/*!40000 ALTER TABLE `top10mysthrill` DISABLE KEYS */;
INSERT INTO `top10mysthrill` VALUES ('tt0114814','Bryan Singer','The Usual Suspects','Stephen Baldwin	 Gabriel Byrne	 Benicio Del Toro	 Kevin Pollak',8.6,760882,106,'Won 2 Oscars. Another 32 wins & 16 nominations.',1995,'English	 Hungarian	 Spanish	 French','Crime	 Drama	 Mystery','Christopher McQuarrie','https://images-na.ssl-images-amazon.com/images/M/MV5BMzI1MjI5MDQyOV5BMl5BanBnXkFtZTcwNzE4Mjg3NA@@._V1_SX300.jpg',2,0,48),('tt0102926','Jonathan Demme','The Silence of the Lambs','Jodie Foster	 Lawrence A. Bonney	 Kasi Lemmons	 Lawrence T. Wrentz',8.6,915164,118,'Won 5 Oscars. Another 48 wins & 36 nominations.',1991,'English','Crime	 Drama	 Thriller','Thomas Harris (novel)	 Ted Tally (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTQ2NzkzMDI4OF5BMl5BanBnXkFtZTcwMDA0NzE1NA@@._V1_SX300.jpg',5,0,84),('tt0407887','Martin Scorsese','The Departed','Leonardo DiCaprio	 Matt Damon	 Jack Nicholson	 Mark Wahlberg',8.5,894160,151,'Won 4 Oscars. Another 90 wins & 123 nominations.',2006,'English	 Cantonese','Crime	 Drama	 Thriller','William Monahan (screenplay)	 Alan Mak	 Felix Chong','https://images-na.ssl-images-amazon.com/images/M/MV5BMTI1MTY2OTIxNV5BMl5BanBnXkFtZTYwNjQ4NjY3._V1_SX300.jpg',4,0,213),('tt0103064','James Cameron','Terminator 2: Judgment Day','Arnold Schwarzenegger	 Linda Hamilton	 Edward Furlong	 Robert Patrick',8.5,759731,137,'Won 4 Oscars. Another 21 wins & 22 nominations.',1991,'English	 Spanish','Action	 Sci-Fi	 Thriller','James Cameron	 William Wisher Jr.','https://images-na.ssl-images-amazon.com/images/M/MV5BZDM2YjYwYWMtMWZlNi00ZDQxLWExMDctMDAzNzQ0OTkzZjljXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',4,0,43),('tt0033467','Orson Welles','Citizen Kane','Joseph Cotten	 Dorothy Comingore	 Agnes Moorehead	 Ruth Warrick',8.4,303815,119,'Won 1 Oscar. Another 7 wins & 12 nominations.',1941,'English','Drama	 Mystery','Herman J. Mankiewicz (original screen play)	 Orson Welles (original screen play)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTQ2Mjc1MDQwMl5BMl5BanBnXkFtZTcwNzUyOTUyMg@@._V1_SX300.jpg',1,0,19),('tt0062622','Stanley Kubrick','2001: A Space Odyssey','Keir Dullea	 Gary Lockwood	 William Sylvester	 Daniel Richter',8.3,437932,149,'Won 1 Oscar. Another 13 wins & 7 nominations.',1968,'English	 Russian','Adventure	 Mystery	 Sci-Fi','Stanley Kubrick (screenplay)	 Arthur C. Clarke (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTZkZTBhYmUtMTIzNy00YTViLTg1OWItNGUwMmVlN2FjZTVkXkEyXkFqcGdeQXVyNDYyMDk5MTU@._V1_SX300.jpg',1,0,20),('tt0041959','Carol Reed','The Third Man','Joseph Cotten	 Alida Valli	 Orson Welles	 Trevor Howard',8.3,116034,93,'Won 1 Oscar. Another 4 wins & 4 nominations.',1949,'English	 German	 Russian','Film-Noir	 Mystery	 Thriller','Graham Greene (by)	 Graham Greene (screen play)','https://images-na.ssl-images-amazon.com/images/M/MV5BZjQxYmRkMjgtMmZkZi00ZDYyLTk5OTktZWZjZTEzNGZlMWEwXkEyXkFqcGdeQXVyNDYyMDk5MTU@._V1_SX300.jpg',1,0,8),('tt0119488','Curtis Hanson','L.A. Confidential','Kevin Spacey	 Russell Crowe	 Guy Pearce	 James Cromwell',8.3,422629,138,'Won 2 Oscars. Another 84 wins & 77 nominations.',1997,'English','Crime	 Drama	 Mystery','James Ellroy (novel)	 Brian Helgeland (screenplay)	 Curtis Hanson (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BMDBlYzAwZDktNzM2MS00YzBlLWI4ODQtZTlkNmMxZDc3NGRkXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',2,0,161),('tt0032976','Alfred Hitchcock','Rebecca','Laurence Olivier	 Joan Fontaine	 George Sanders	 Judith Anderson',8.2,89770,130,'Won 2 Oscars. Another 2 wins & 10 nominations.',1940,'English	 French','Drama	 Film-Noir	 Mystery','Daphne Du Maurier (celebrated novel)	 Robert E. Sherwood (screen play)	 Joan Harrison (screen play)	 Philip MacDonald (adaptation)	 Michael Hogan (adaptation)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTM5ODA4ODMzM15BMl5BanBnXkFtZTcwOTA2NTEwNA@@._V1._CR922314458_SY132_CR0089132_AL_.jpg_V1_SX300.jpg',2,0,12),('tt0071315','Roman Polanski','Chinatown','Jack Nicholson	 Faye Dunaway	 John Huston	 Perry Lopez',8.2,222015,130,'Won 1 Oscar. Another 20 wins & 23 nominations.',1974,'English	 Cantonese	 Spanish','Drama	 Mystery	 Thriller','Robert Towne','https://images-na.ssl-images-amazon.com/images/M/MV5BMTZiZTA5MWItNTgyMy00ZGZkLThjNGQtOWI0MTU5ZDI4NmJmXkEyXkFqcGdeQXVyNjc1NTYyMjg@._V1_SX300.jpg',1,0,43);
/*!40000 ALTER TABLE `top10mysthrill` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-12 11:55:24
