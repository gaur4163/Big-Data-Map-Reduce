-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: bigdata
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `top10horrors`
--

DROP TABLE IF EXISTS `top10horrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `top10horrors` (
  `imdbID` text,
  `Director` text,
  `Title` text,
  `Actirs` text,
  `imdbRating` double DEFAULT NULL,
  `imdbVote` int(11) DEFAULT NULL,
  `runtime` int(11) DEFAULT NULL,
  `Awards` text,
  `Year` int(11) DEFAULT NULL,
  `Language` text,
  `Country` text,
  `Writer` text,
  `Poster` text,
  `OscarWinner` int(11) DEFAULT NULL,
  `OscarNominated` int(11) DEFAULT NULL,
  `otherAwards` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top10horrors`
--

LOCK TABLES `top10horrors` WRITE;
/*!40000 ALTER TABLE `top10horrors` DISABLE KEYS */;
INSERT INTO `top10horrors` VALUES ('tt0078748','Ridley Scott','Alien','Tom Skerritt	 Sigourney Weaver	 Veronica Cartwright	 Harry Dean Stanton',8.5,580179,117,'Won 1 Oscar. Another 16 wins & 19 nominations.',1979,'English	 Spanish','Horror	 Sci-Fi','Dan O\'Bannon (story)	 Ronald Shusett (story)	 Dan O\'Bannon (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BNDNhN2IxZWItNGEwYS00ZDNhLThiM2UtODU3NWJlZjBkYjQxXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',1,0,35),('tt0056687','Robert Aldrich','What Ever Happened to Baby Jane?','Bette Davis	 Joan Crawford	 Victor Buono	 Wesley Addy',8.1,32109,134,'Won 1 Oscar. Another 1 win & 11 nominations.',1962,'English','Drama	 Horror	 Thriller','Henry Farrell (from the novel by)	 Lukas Heller (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BZmI0M2VmNTgtMWVhYS00Zjg1LTk1YTYtNmJmMjRkZmMwYTc2XkEyXkFqcGdeQXVyNTA4NzY1MzY@._V1_SX300.jpg',1,0,12),('tt0070047','William Friedkin','The Exorcist','Ellen Burstyn	 Max von Sydow	 Lee J. Cobb	 Kitty Winn',8,289957,122,'Won 2 Oscars. Another 14 wins & 15 nominations.',1973,'English	 Latin	 Greek	 French	 German	 Arabic	 Kurdish','Horror','William Peter Blatty (written for the screen by)	 William Peter Blatty (novel)','https://images-na.ssl-images-amazon.com/images/M/MV5BYzczOGRlMzQtNDAzMS00MjdlLTk5Y2QtNTM3MDE3NjRkYzQwXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg',2,0,29),('tt0063522','Roman Polanski','Rosemary\'s Baby','Mia Farrow	 John Cassavetes	 Ruth Gordon	 Sidney Blackmer',8,144250,137,'Won 1 Oscar. Another 9 wins & 12 nominations.',1968,'English','Drama	 Horror','Ira Levin (novel)	 Roman Polanski (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BMjE3NzE4NzkyNl5BMl5BanBnXkFtZTgwNTYyODgwNzE@._V1_SX300.jpg',1,0,21),('tt0022835','Rouben Mamoulian','Dr. Jekyll and Mr. Hyde','Fredric March	 Miriam Hopkins	 Rose Hobart	 Holmes Herbert',7.7,9513,98,'Won 1 Oscar. Another 2 wins & 2 nominations.',1931,'English','Horror	 Sci-Fi','Samuel Hoffenstein (screen play)	 Percy Heath (screen play)	 Robert Louis Stevenson (based on the novel by)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTc1MjE3NTMxNV5BMl5BanBnXkFtZTgwMTQ0NzkxMjE@._V1_SX300.jpg',1,0,4),('tt0037988','Albert Lewin','The Picture of Dorian Gray','George Sanders	 Hurd Hatfield	 Donna Reed	 Angela Lansbury',7.6,9320,110,'Won 1 Oscar. Another 2 wins & 2 nominations.',1945,'English','Drama	 Fantasy	 Horror','Albert Lewin (screen play)	 Oscar Wilde (based upon the novel by)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTI2NjUyMjcyM15BMl5BanBnXkFtZTcwODAwMzU3Mg@@._V1_SX300.jpg',1,0,4),('tt0082010','John Landis','An American Werewolf in London','Joe Belcher	 David Naughton	 Griffin Dunne	 David Schofield',7.6,66260,97,'Won 1 Oscar. Another 2 wins & 3 nominations.',1981,'English','Comedy	 Horror','John Landis','https://images-na.ssl-images-amazon.com/images/M/MV5BNTYzMDk3MzIyNV5BMl5BanBnXkFtZTgwOTM2OTE4MzE@._V1_SX300.jpg',1,0,5),('tt0075005','Richard Donner','The Omen','Gregory Peck	 Lee Remick	 David Warner	 Billie Whitelaw',7.6,83045,111,'Won 1 Oscar. Another 3 wins & 8 nominations.',1976,'English	 Latin	 Italian','Horror	 Thriller','David Seltzer','https://images-na.ssl-images-amazon.com/images/M/MV5BODE2ODQ5MzYyNl5BMl5BanBnXkFtZTgwODc1Mjc1MDE@._V1_SX300.jpg',1,0,11),('tt0103874','Francis Ford Coppola','Bram Stoker\'s Dracula','Gary Oldman	 Winona Ryder	 Anthony Hopkins	 Keanu Reeves',7.5,147096,128,'Won 3 Oscars. Another 12 wins & 15 nominations.',1992,'English	 Romanian	 Greek	 Bulgarian	 Latin','Fantasy	 Horror','Bram Stoker (novel)	 James V. Hart (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BMTYyOTM5NzU3Nl5BMl5BanBnXkFtZTgwOTQxNjAxNzE@._V1_SX300.jpg',3,0,27),('tt0091064','David Cronenberg','The Fly','Jeff Goldblum	 Geena Davis	 John Getz	 Joy Boushel',7.5,121552,96,'Won 1 Oscar. Another 5 wins & 11 nominations.',1986,'English','Drama	 Horror	 Sci-Fi','George Langelaan (short story)	 Charles Edward Pogue (screenplay)	 David Cronenberg (screenplay)','https://images-na.ssl-images-amazon.com/images/M/MV5BNjI3OGRhYjUtZmY1MC00N2JlLWJjMDUtYmViNTE0NDA0NzZlXkEyXkFqcGdeQXVyNTI4MjkwNjA@._V1_SX300.jpg',1,0,16);
/*!40000 ALTER TABLE `top10horrors` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-12 11:55:25
