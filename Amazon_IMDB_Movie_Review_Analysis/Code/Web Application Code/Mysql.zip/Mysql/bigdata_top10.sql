-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: bigdata
-- ------------------------------------------------------
-- Server version	5.7.14-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `top10`
--

DROP TABLE IF EXISTS `top10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `top10` (
  `idtop` int(11) NOT NULL AUTO_INCREMENT,
  `imdbID` varchar(45) DEFAULT NULL,
  `Director` varchar(200) DEFAULT NULL,
  `Title` varchar(200) DEFAULT NULL,
  `Actirs` varchar(200) DEFAULT NULL,
  `imdbRating` float DEFAULT NULL,
  `imdbVote` int(11) DEFAULT NULL,
  `runTime` int(11) DEFAULT NULL,
  `Awards` varchar(200) DEFAULT NULL,
  `Year` int(11) DEFAULT NULL,
  `Genre` varchar(100) DEFAULT NULL,
  `Poster` varchar(300) DEFAULT NULL,
  `amazonID` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`idtop`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top10`
--

LOCK TABLES `top10` WRITE;
/*!40000 ALTER TABLE `top10` DISABLE KEYS */;
INSERT INTO `top10` VALUES (1,'tt0071562','Francis Ford Coppola','The Godfather: Part II','Al Pacino	 Robert Duvall	 Diane Keaton	 Robert De Niro',9,813863,202,'Won 6 Oscars. Another 10 wins & 20 nominations.',1974,'Crime	 Drama','https://images-na.ssl-images-amazon.com/images/M/MV5BOTE1MTBiYzYtMDI1OC00ZTUxLTg0ZWQtZjdjMzA0OTM1NGMwXkEyXkFqcGdeQXVyMjUzOTY1NTc@._V1_SX300.jpg','B00004CJ4X'),(2,'tt0137523','David Fincher','Fight Club','Edward Norton	 Brad Pitt	 Meat Loaf	 Zach Grenier',8.8,1384393,139,'Nominated for 1 Oscar. Another 10 wins & 31 nominations.',1999,'Drama','https://images-na.ssl-images-amazon.com/images/M/MV5BNGM2NjQxZTAtMmU5My00YTk5LWFmOWMtYjZlYzk4YzMwNjFlXkEyXkFqcGdeQXVyNDk3NzU2MTQ@._V1_SX300.jpg','B00004W5UB'),(3,'tt0111161','Frank Darabont','The Shawshank Redemption','Tim Robbins	 Morgan Freeman	 Bob Gunton	 William Sadler',9.3,1725904,142,'Nominated for 7 Oscars. Another 19 wins & 30 nominations.',1994,'Crime Drama ','https://images-na.ssl-images-amazon.com/images/M/MV5BODU4MjU4NjIwNl5BMl5BanBnXkFtZTgwMDU2MjEyMDE@._V1_SX300.jpg',NULL),(4,'tt0109830','Robert Zemeckis','Forrest Gump','Tom Hanks	 Rebecca Williams	 Sally Field	 Michael Conner Humphr',8.8,1291467,142,'Won 6 Oscars. Another 39 wins & 65 nominations.',1994,'Comedy Drama','https://images-na.ssl-images-amazon.com/images/M/MV5BYThjM2MwZGMtMzg3Ny00NGRkLWE4M2EtYTBiNWMzOTY0YTI4XkEyXkFqcGdeQXVyNDYyMDk5MTU@._V1_SX300.jpg','B00004CRN1'),(5,'tt1375666','Christopher Nolan','Inception','Leonardo DiCaprio	 Joseph Gordon-Levitt	 Ellen Page	 Tom Har',8.8,1501172,148,'Won 4 Oscars. Another 144 wins & 198 nominations.',2010,'Action	 Advente	 Sci-F','https://images-na.ssl-images-amazon.com/images/M/MV5BMjAxMzY3NjcxNF5BMl5BanBnXkFtZTcwNTI5OTM0Mw@@._V1_SX300.jpg',NULL),(6,'tt0133093','Lana Wachowski	 Lilly Wachowski','The Matrix','Keanu Reeves	 Laurence Fishburne	 Carrie-Anne Moss	 Hugo Weavi',8.7,1244275,136,'Won 4 Oscars. Another 33 wins & 43 nominations.',1999,'Action 	 Sci-Fi','https://images-na.ssl-images-amazon.com/images/M/MV5BMDMyMmQ5YzgtYWMxOC00OTU0LWIwZjEtZWUwYTY5MjVkZjhhXkEyXkFqcGdeQXVyNDYyMDk5MTU@._V1_SX300.jpg','B00004VYO6'),(7,'tt0317248','Fernando Meirelles	 Kí€Œçtia Lund','City of God','Alexandre Rodrigues	 Leandro Firmino	 Phellipe Haagensen	 Douglas S',8.7,544402,130,'Nominated for 4 Oscars. Another 65 wins & 37 nominations.',2002,'Crime	 Drama','https://images-na.ssl-images-amazon.com/images/M/MV5BMjA4ODQ3ODkzNV5BMl5BanBnXkFtZTYwOTc4NDI3._V1_SX300.jpg',NULL),(8,'tt0090605','James Cameron','Aliens','Sigourney Weaver	 Carrie Henn	 Michael Biehn	 Paul Reiser',8.4,500006,137,'Won 2 Oscars. Another 17 wins & 22 nominations.',1986,'Action	 Adventure	 Sci-Fi','https://images-na.ssl-images-amazon.com/images/M/MV5BOTYxZGJkNDUtOWRmMy00M2JjLWJiNjAtNTE0OWU0ODU1MDdiXkEyXkFqcGdeQXVyMTQxNzMzNDI@._V1_SX300.jpg','6304789440'),(9,'tt2096673','Pete Docter	 Ronnie Del Carmen','Inside Out','Amy Poehler	 Phyllis Smith	 Richard Kind	 Bill Hader',8.2,375070,95,'Won 1 Oscar. Another 92 wins & 95 nominations.',2015,'Animation Adventure	 Comedy','https://images-na.ssl-images-amazon.com/images/M/MV5BOTgxMDQwMDk0OF5BMl5BanBnXkFtZTgwNjU5OTg2NDE@._V1_SX300.jpg','B000063KL4');
/*!40000 ALTER TABLE `top10` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-12 11:55:24
